/**
 * WiFiManager advanced demo, contains advanced configurartion options
 * Implements TRIGGEN_PIN button press, press for ondemand configportal, hold for 3 seconds for reset settings.
 */
#include "M5Atom.h"
#include <WiFiManager.h> // https://github.com/tzapu/WiFiManager
#include <Redis.h>
#include <ArduinoJson.h>
#include "time.h"

//#define WIFI_SSID "Williams Farms"
//#define WIFI_PASSWORD "V3g3t@bl3s!"
#define WIFI_SSID "TrueShot"
#define WIFI_PASSWORD "mindshare"
#define REDIS_ADDR "54.173.177.227"
#define REDIS_PORT 7721
#define REDIS_PASSWORD "GpC}Xdp)S(+8c"
#define ZT "zt4"
#define DATASET "sandif1zt"
#define TRIGGER_PIN 0
#define POST_FREQUENCY 60
#define POST_FREQUENCY1 1


const char* ntpServer = "pool.ntp.org";
const long  gmtOffset_sec = 0;
const int   daylightOffset_sec = 3600;
int pressCount; 
String tagTemplate;
String theTag;
String combined;
String zt = ZT;
String dataset = DATASET;
bool wm_nonblocking = false; // change to true to use non blocking
WiFiClient redisConn;
Redis *gRedis = nullptr;
WiFiManager wm; // global wm instance
WiFiManagerParameter custom_field; // global param ( for non blocking w params )
void setup() {
  WiFi.mode(WIFI_STA); // explicitly set mode, esp defaults to STA+AP  
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);  
  Serial.begin(115200);
  Serial2.begin(9600, SERIAL_8N1, 22, 19);
  Serial.setDebugOutput(true);  
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to the WiFi");
  while (WiFi.status() != WL_CONNECTED)
  {
      delay(250);
      Serial.print(".");
  }
  Serial.println();
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());

  if (!redisConn.connect(REDIS_ADDR, REDIS_PORT))
  {
      Serial.println("Failed to connect to the Redis server!");
      return;
  }

  gRedis = new Redis(redisConn);
  auto connRet = gRedis->authenticate(REDIS_PASSWORD);
  if (connRet == RedisSuccess)
  {
      Serial.printf("Connected to the Redis server at %s!\n", REDIS_ADDR);
  }
  else
  {
      Serial.printf("Failed to authenticate to the Redis server! Errno: %d\n", (int)connRet);
      return;
  }
  //configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  Serial.println("\n Starting");
  M5.begin(true, false,true);
  delay(50);
  M5.dis.drawpix(0, 0x00ff00);
  std::vector<const char *> menu = {"wifi","info","param","sep","restart","exit"};
  tagTemplate = gRedis->get("sandif1zt:template");
}
unsigned long lastPost = 0;
unsigned long lastPost1 = 0;
StaticJsonDocument<2048> doc;
void loop() {
  auto startTime = millis();
  auto startTime1 = millis();
  if (!lastPost || startTime - lastPost > POST_FREQUENCY * 1000) {
    //doc["analog"] = analogRead(ANALOG_INPUT);
    doc["wifi-rssi"] = WiFi.RSSI();
    doc["uptime-ms"] = startTime;
    String jsonStr;
    serializeJson(doc, jsonStr);
    Serial.printf("Sending JSON paayload:\n\t'%s'\n", jsonStr.c_str());
    Serial.println(gRedis->lpush("sandif1zt:zt4:status",jsonStr.c_str()));
    doc.clear();
    lastPost = millis();
    Serial.println("--------");
    Serial.println(gRedis->llen("sandif1zt:ztjobs"));
    Serial.println("--------");    
  }
  M5.dis.drawpix(0, 0x0000ff);
  M5.update();    //You need to add m5.update () to read the state of the key, see System for details
  if (M5.Btn.pressedFor(150)) {
    delay(150);
    pressCount++;
    Serial.println("Button is pressed.");
    Serial.println(pressCount);
    gRedis->rpush("sandif1zt:ztjobs","zt4");
  }
  if (!lastPost1 || startTime1 - lastPost1 > POST_FREQUENCY1 * 1000) {
    lastPost1 = millis();
    while (gRedis->llen("sandif1zt:zt4")>0) {
      theTag = gRedis->lpop("sandif1zt:zt4");
      Serial.println(theTag);
      Serial2.println(tagTemplate+theTag);
    }
  }
}

