const bb = require("./lib/barebones");
const { PubSub } = require("./lib/pubsub");
var client1 = require('redis').createClient({
   host:'54.173.45.122',
   port:'6379',
   password:'e2c7dd14d6961',
   legacyMode: true
});
process.on("exit", function () {
   client1.quit()
})
client1.rpush('fromReceiveAnnounce',"worked")

class AnnouncePingBack extends PubSub {
  constructor() {
    super("ZebraTail/announce");
  }

  async sub(payload, topic, dup, qos, retain) {
    console.log(
      `Publish received. topic:"${topic}" dup:${dup} qos:${qos} retain:${retain}`,
    );
    let json;
    try {
      json = await payload;
      const msg = JSON.parse(json);
      console.log(`payload:`, msg);
      if (msg.type === 'initialize') {
         client1.rpush('initialized',json)
      } else if (msg.type === 'button') {
         client1.rpush('TagsToPrint',json)
      }
    } catch (x) {
      console.error("payload error:", x, `\n${json}`);
    }
  }
}

const args = {
  topic: "ZebraTail/chat",
  message: "por qué no los dos",
  count: 2,
};

async function main(argv) {
  const connection = await bb.connect();

  // Bare minimum single message, or more complicated multi-message object
  // console.log(await sendOne(connection, argv.topic, argv.message));
  // await new Echo(argv.topic, argv.message, argv.count).execute(connection);
  await new AnnouncePingBack().execute(connection);

  await bb.disconnect(connection);
}

main(args);